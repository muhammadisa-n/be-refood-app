-- AlterTable
ALTER TABLE `orders` ADD COLUMN `jenis_layanan` VARCHAR(20) NULL;

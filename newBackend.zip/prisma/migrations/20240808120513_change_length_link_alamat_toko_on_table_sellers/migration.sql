-- AlterTable
ALTER TABLE `sellers` MODIFY `link_map_alamat_toko` VARCHAR(100) NULL;
